# Binar Challenge Chapter 6
Hi! 🚀
### Racikan tambahan
- ROOM
- Data Store
- View Model
- Coroutine
- Retrofit 2 + OkHttp
- Navigation Component
- Lifecycle Component
- Recycler View + Diffutils
- **MVVM Based**
- Material Design Based
### Third party
- on Github @dhaval2404 Image Picker
### Gif
![hmm](https://raw.githubusercontent.com/anantyan/Binar-Android-Chapter-6/main/screenshoot/Record_2022-04-09-03-50-13.gif)
### Screenshoot aplikasi
![hmm](https://raw.githubusercontent.com/anantyan/Binar-Android-Chapter-6/main/screenshoot/pages.png)
![hmm](https://raw.githubusercontent.com/anantyan/Binar-Android-Chapter-6/main/screenshoot/pages___1.png)
![hmm](https://raw.githubusercontent.com/anantyan/Binar-Android-Chapter-6/main/screenshoot/pages___2.png)
![hmm](https://raw.githubusercontent.com/anantyan/Binar-Android-Chapter-6/main/screenshoot/Pages___3.png)
